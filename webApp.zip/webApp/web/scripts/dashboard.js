/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function () {
    
    var init = function(){
        
        //check session
       app.checkSession();  //validating session
        
        //resizing height of main div's
        var winHeight = $(window).height();
        var boxHeight = winHeight - 58;
        $('.app-west').css("height", boxHeight);
        $('.app-center').css("height", boxHeight);
        
        $('.toplevel').click(function(){
            var parent = $(this).parent("li.parent");
            if(parent.hasClass("open")){
                parent.removeClass("open");
                parent.find(".sub").slideToggle(250, function(){});
            }else{
                parent.addClass("open");
                parent.find(".sub").slideToggle(250, function(){});
            }
            return false;
        });
        
        app.loadEmployeeData();
        
        $dialog = $("#employeeRegistration");
        $dialog.dialog({
            autoOpen: false,
            modal: true,
            width:800,
            title:'Add Employee',
            minHeight:400
        });
                
        $('.addEmployee').on('click',function(){
            app.manageEmployee();
        });
        $('.registerCancel').on('click',function(){
           app.registerCancel();
        });
        $('#validateAddEmployeeBtn').on('click',function(){
           app.registerEmployee();
        });
    } 
    var app = {
        checkSession:function(){
            $.ajax({
                    type: "POST",
                    url: 'jspfiles/validate.jsp',
                    success:function(response){
                        var data = eval('('+response+')');
                       
                        if(data.valid){
                            $('.wrap').removeClass('hide');
                        }else{
                            app.signOut();
                        }
                    },
                    async:false
            });
        },
        signOut:function(){
            var _u = 'jspfiles/signOut.jsp';
           app._r(_u);
        },
        _r:function(url){
            window.top.location.href = url;
        },
        loadEmployeeData:function(){
                
                $('#manageEmployeeGridTable').datagrid({
                    url:'application.jsp?methodName=viewEmployee', 
                    //title:"Employee Details",
                    striped:true,
                    remoteSort:false,
                    pagination:true,
                    pageSize:20,
                    //pageSize:5,
                    pageList:[20,40,60,80,100],
                    //pageList:[5,10,15,20,25],
                    //height:300,
                    //width:1000,
                    fitColumns:true,
                    singleSelect:true,
                    showFooter:true,
                    //view: detailview,
                    columns:[[
                        {field:'employeeId',title:'Id',width:65,align:'left',sortable:true,halign:'center'},    
                        {field:'employeeName',title:'Name',width:100,sortable:true,halign:'center'},
                        {field:'employeeEmail',title:'Email',width:65,align:'left',halign:'center'},
                        {field:'projectJoiningDate',title:'Project Allocation Date',width:70,align:'center',sortable:true,halign:'center'},
                        {field:'contactNumber',title:'Contact Details',width:70,align:'left',halign:'center'},
                        {field:'isActive',title:'Active',width:70,align:'center',sortable:true,halign:'center'}
                    ]],
//                    detailFormatter:function(index,row){
//                        return '<div id="ddv-' + index + '" style="padding:5px 0"></div>';
//                    },
//                    onExpandRow: function(index,row){
//                        $('#ddv-'+index).panel({
//                            border:false,
//                            cache:false,
//                            //href:'POSManager.jsp?orderid='+row.orderid+'&flag=3',
//                            onLoad:function(){
//                            $('#Reports').datagrid('fixDetailRowHeight',index);
//                            }
//                        });
//                        $('#Reports').datagrid('fixDetailRowHeight',index);
//                    },
                    onLoadSuccess: function(data){
                        if(data.total==0){
                            $('.pagination-info').html("No record to display");
                        }
                    }
                });
        },
        manageEmployee:function(){
            $('.registerErrMsg').html(''); 
            $("#txtallocationDate").datepicker({
                dateFormat: "yy-mm-dd"
              });
            $('#validateAddEmployeeBtn').attr("disabled",false);
            $("#employeeRegisterForm")[0].reset();
            $dialog.dialog("open");
            return false;
        },
        registerCancel:function(){
            $dialog.dialog("close"); 
        },
        registerEmployee:function(){
            $('.registerErrMsg').html('');  
            var txtfname = $.trim($("#txtfname").val());
            var txtlname = $.trim($("#txtlname").val());
            var txtempid = $.trim($("#txtemployeeid").val());
            var txtemail = $.trim($("#txtemail").val());
            var txtallocationDate = $.trim($("#txtallocationDate").val());
            var txtcontact = $.trim($("#txtcontact").val());
            
            var cnt=0;
            var pieces =new Array();
            if(txtfname ==""){
                pieces[cnt]= " valid first name";
                cnt++;
            }
            if(txtlname ==""){
                pieces[cnt]= " valid last name";
                cnt++;
            }
            if(txtempid==""){
                pieces[cnt]= " employee id";
                cnt++;   
            }else if(!txtempid.match(/^[0-9]+$/)){
                pieces[cnt]= " enter numeric characters only for employee id";
                cnt++;   
            }
            if(txtemail==""){
                pieces[cnt]= " email";
                cnt++;   
            }
            if(txtallocationDate==""){
                pieces[cnt]= " allocation date";
                cnt++;   
            }
            if(txtcontact==""){
                pieces[cnt]= " contact number";
                cnt++;   
            }
            if(cnt==0){
                $('#validateAddEmployeeBtn').attr("disabled",true);
                $.ajax({
                   type: "POST",
                   url: "application.jsp?methodName=registerEmployee",
                   data: $("#employeeRegisterForm").serialize(), 
                   success: function(response){
                       var data = eval('('+response+')');

                        if(data.success){
                            $dialog.dialog("close");
                            //$scope.showMessageBox(data[1]);
                        }else{
                            $('.registerErrMsg').html(data.msg);
                            $('#validateAddEmployeeBtn').attr("disabled",false);
                        }
                   },
                   error:function(){
                        $('.registerErrMsg').html("Some error occured. Please try again.");
                        $('#validateAddEmployeeBtn').attr("disabled",false);
                   }
                });
            }else{
                var array_cnt=0;
                var msg='';
                while (array_cnt < pieces.length)
                {
                    if((array_cnt+1)==(pieces.length-1))
                            msg=msg+pieces[array_cnt]+" and ";
                    else if((pieces.length-1)==array_cnt)
                            msg=msg+pieces[array_cnt];
                    else
                            msg=msg+pieces[array_cnt]+", ";

                    array_cnt+=1;
                }
                $('.registerErrMsg').html("Please provide"+msg);
            }
        }
    }
    
   $(function(){
       init();
   }); 
}());
