/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function () {
    
    var init = function(){
        $dialog = $("#dialogueOpener");
        $dialog.dialog({
            autoOpen: false,
            modal: true,
            width:400,
            title:'Loading...',
            minHeight:150
        });
        
       $('#signUp').on('click',function(){
           app.signup();
       });
        $('#signIn').on('click',function(){
           app.signin();
       });
    } 
    var app = {
        signin:function(){
            var errorCnt=0;
            var pieces =new Array();
            var domainname = $.trim($("#loginDomainName").val());
            var username = $.trim($("#loginUserName").val());
            var password = $.trim($("#loginPassword").val());
            
            if(domainname==""){
                pieces[errorCnt]= " domain name";
                errorCnt++;
            }
            if(username==""){
                pieces[errorCnt]= " username";
                errorCnt++;
            }
            if(password==""){
                pieces[errorCnt]= " password";
                errorCnt++;
            }
             if(errorCnt==0){
                $('#login .errorMessge').html("");
                $('#signIn').attr("disabled",true);
                $dialog.dialog({title:'Loading...'});
                $('#dialogueOpener img').show();
                $('#dialogueOpener .server-message').html("");
                
                $dialog.dialog("open");
                $.ajax({
                    type: "POST",
                    url: "jspfiles/auth.jsp",
                    data: $("#signinForm").serialize(), 
                    success: function(response){
                        
                         var data = eval('('+response+')');
                         if(!data.success){
                            $dialog.dialog({title:'Error'});
                            $('#dialogueOpener img').hide();
                            $('#dialogueOpener .server-message').html("Authentication failed. Please enter valid data.");
                            $('#signIn').attr("disabled",false);
                         }else{
                             window.top.location.href = "dashboard.jsp";
                         }
                    },
                    error:function(){
                         $dialog.dialog({title:'Error'});
                         $('#dialogueOpener img').hide();
                         $('#dialogueOpener .server-message').html("Some error occured. Please try again.");
                         $('#signUp').attr("disabled",false);
                    }
                });
             }else{
                 app.buildErrorMessage(pieces,'#login .errorMessge');
             }
        },
        signup:function(){
            var errorCnt=0;
            var pieces =new Array();
            var domainname = $.trim($("#domainname").val());
            var fname = $.trim($("#firstname").val());
            var lname = $.trim($("#lastname").val());
            var username = $.trim($("#username").val());
            var password = $.trim($("#passwordsignup").val());
            var conf_password = $.trim($("#passwordsignup_confirm").val());
            
            if(domainname==""){
                pieces[errorCnt]= " domain name";
                errorCnt++;
            }
            if(fname==""){
                pieces[errorCnt]= " first name";
                errorCnt++;
            }
            if(lname==""){
                pieces[errorCnt]= " last name";
                errorCnt++;
            }
            if(username==""){
                pieces[errorCnt]= " username";
                errorCnt++;
            }
            if(password==""){
                pieces[errorCnt]= " password";
                errorCnt++;
            }
            if(conf_password==""){
                pieces[errorCnt]= " confirm password";
                errorCnt++;
            }
            if(password!="" && conf_password!=""){
                if(password!=conf_password){
                     pieces[errorCnt]= " valid confirm password";
                     errorCnt++;
                }
            }
            if(errorCnt==0){
                $('#register .errorMessge').html("");
                $('#signUp').attr("disabled",true);
                $dialog.dialog({title:'Loading...'});
                $('#dialogueOpener img').show();
                $('#dialogueOpener .server-message').html("");
                
                $dialog.dialog("open");
                $.ajax({
                    type: "POST",
                    url: "signup.jsp",
                    data: $("#registerForm").serialize(), 
                    success: function(response){
                        
                         var data = eval('('+response+')');
                         if(data.success){
                            $dialog.dialog({title:'Success'});
                            $('#dialogueOpener img').hide();
                            $('#dialogueOpener .server-message').html("Domain registered successfully. Please login now to continue.");
                            $('#signUp').attr("disabled",false);
                         }else if(data.failure===2){
                            $dialog.dialog({title:'Error'});
                            $('#dialogueOpener img').hide();
                            $('#dialogueOpener .server-message').html("Domain name already exists, please try with other domain name.");
                            $('#signUp').attr("disabled",false);
                         }else{
                            $dialog.dialog({title:'Error'});
                            $('#dialogueOpener img').hide();
                            $('#dialogueOpener .server-message').html("Some error occured. Please try again.");
                            $('#signUp').attr("disabled",false);
                         }
                    },
                    error:function(){
                         $dialog.dialog({title:'Error'});
                         $('#dialogueOpener img').hide();
                         $('#dialogueOpener .server-message').html("Some error occured. Please try again.");
                         $('#signUp').attr("disabled",false);
                    }
                });
            }else{
                app.buildErrorMessage(pieces,'#register .errorMessge');
            }
        },
        buildErrorMessage:function(pieces,selector){
            var array_cnt=0;
            var msg='';
            while (array_cnt < pieces.length)
            {
                if((array_cnt+1)==(pieces.length-1))
                        msg=msg+pieces[array_cnt]+" and ";
                else if((pieces.length-1)==array_cnt)
                        msg=msg+pieces[array_cnt];
                else
                        msg=msg+pieces[array_cnt]+", ";

                array_cnt+=1;
            }
            $(selector).html("Please provide"+msg);
        }
    }
    
   $(function(){
       init();
   }); 
}());
