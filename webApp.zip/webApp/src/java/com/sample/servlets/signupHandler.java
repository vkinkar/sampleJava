/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sample.servlets;

import com.sample.common.util.StringUtil;
import com.sample.database.DBUtil;
import com.sample.database.DbPool;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author VISHAL
 */
public class signupHandler {
    public String checkExistsCompany(Connection conn, HttpServletRequest request) throws SQLException{
         String result = "{\"failure\":2}";
         ResultSet rs_main = null;
         PreparedStatement stmt = null;
         try{
            
           String checkCompany = "SELECT COUNT(*) AS count FROM company WHERE subdomain = ?";
            
           rs_main = DBUtil.executeQuery(conn,stmt,checkCompany, new Object[]{request.getParameter("domainname")});   
              
           while(rs_main.next()) {
                 if (rs_main.getInt("count") == 0) {
                    result = "{\"success\":true}";
                }else{
                    result = "{\"failure\":2}";
                }
            }
        }catch(Exception e){
            Logger.getLogger(signupHandler.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            DbPool.closeStatement(stmt);
            DbPool.closeRS(rs_main);
         }
        return result;
    }
    public String signupCompany(Connection conn, HttpServletRequest request) throws SQLException, Exception{
        String result = "{\"failure\":1}";
        String res = null;
        ResultSet rs_main = null;
        PreparedStatement stmt = null;
         
        String username = request.getParameter("username");
        try{
            if (!(StringUtil.isNullOrEmpty(username))) {
                res = checkExistsCompany(conn,request);
                if (!res.contains("failure")) {
                    String uid = UUID.randomUUID().toString();
                    String cid = UUID.randomUUID().toString();
                    java.sql.Date sqldt = new java.sql.Date(new java.util.Date().getTime());

                    String subdomain = request.getParameter("domainname").toString();
                    String fname = request.getParameter("firstname").toString();
                    String lname = request.getParameter("lastname").toString();
                    String pwd = request.getParameter("passwordsignup_confirm").toString();

                    String createUser = "INSERT INTO userlogin (userid, username, password) VALUES (?,?,?)";
                    DBUtil.executeUpdate(conn,stmt,createUser, new Object[]{uid,username,pwd});

                    String createCompany = "insert into company(companyid,subdomain,createdby,createdon,isActive) values(?,?,?,?,1)";
                    DBUtil.executeUpdate(conn,stmt,createCompany, new Object[]{cid,subdomain,uid,sqldt});

                    String updateUserInfo = "INSERT INTO users (userid,fname, lname,companyid,createdon,isActive) VALUES (?,?,?,?,?,1)";
                    DBUtil.executeUpdate(conn,stmt,updateUserInfo, new Object[]{uid,fname,lname,cid,sqldt});

                    result = "{\"success\":true}";
                  }else{
                    result = res;
                }
            }
        }catch(Exception e){
                throw e;
        }finally{
            DbPool.closeStatement(stmt);
            DbPool.closeRS(rs_main);
        }
        return result;
    }
}
