/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sample.common.util;

/**
 *
 * @author VISHAL
 */
public class StringUtil {
    public static boolean isNullOrEmpty(String s) {
            if (s == null || s.length() == 0) {
                    return true;
            }
            return false;
    }
}
