/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sample.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author VISHAL
 */
public class DbPool {
    static Connection connection = null;
    static DataSource ds = null;
    static{
        try{
             InitialContext initialContext = new InitialContext();
             Context context = (Context) initialContext.lookup("java:comp/env");
             ds = (DataSource) context.lookup("connpool");
             //connection = ds.getConnection();
        }catch(NamingException e){
        }
    }
    public static Connection getConnection() throws SQLException{
        return ds.getConnection();
    }
    public static void quietRollback(Connection conn) throws SQLException{
        if (conn != null) {
                try {
                    conn.rollback();
                }catch(SQLException e) {
                    throw e;
                }
        }
    }
    public static void quietClose(Connection conn) throws SQLException{
        if (conn != null) {
                try {
                    conn.close();
                }catch(SQLException e) {
                    throw e;
                }
        }
    }
    public static void closeStatement(Statement stmt) throws SQLException{
        if (stmt != null) {
                try {
                    stmt.close();
                }catch (SQLException e) {
                   throw e;
                }
        }
    }
    public static void closeRS(ResultSet rs) throws SQLException{
        if (rs != null) {
                try {
                    rs.close();
                }catch (SQLException e) {
                   throw e;
                }
        }
    }
    
}
