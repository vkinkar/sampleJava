/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sample.database;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author VISHAL
 */
public class DBUtil {
    public static ResultSet executeQuery(Connection conn, PreparedStatement stmt, String query,
		Object[] params) throws Exception {
		ResultSet results = null;
                try {
			stmt = conn.prepareStatement(query);
                        if (params != null) {
                            for (int i = 0; i < params.length; i++) {
                                    stmt.setObject(i + 1, params[i]);
                            }
			}
			results = stmt.executeQuery();
		} catch (SQLException e) {
			String message = "SQL: '" + query + "'";
                        throw e;
                }
                return results;
	}
        public static int executeUpdate(Connection conn, PreparedStatement stmt, String sql, Object[] params)
			throws Exception {
		int numRows = 0;
                try {
                    stmt = conn.prepareStatement(sql);
                    if (params != null) {
                            for (int i = 0; i < params.length; i++) {
                                stmt.setObject(i + 1, params[i]);
                            }
                    }
                    numRows = stmt.executeUpdate();
		} catch (SQLException e) {
                    String message = "SQL: '" + sql + "'";
                    throw e;
		}
		return numRows;
	}

}
