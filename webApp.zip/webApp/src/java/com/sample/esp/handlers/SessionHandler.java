package com.sample.esp.handlers;

import com.sample.common.webapp.Users;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SessionHandler {
    
    public static boolean isValidSession(HttpServletRequest request,
            HttpServletResponse response) throws IOException {
        boolean bSuccess = false;
        try {
            if (request.getSession().getAttribute("initialized") != null) {
                bSuccess = true;
            }
        } catch (Exception ex) {
        }
        return bSuccess;
    }

    public boolean validateSession(HttpServletRequest request,
                    HttpServletResponse response) throws IOException {
         return SessionHandler.isValidSession(request, response);
    }

    public void createUserSession(HttpServletRequest request,HttpServletResponse response, Users userObj) {

            HttpSession session = request.getSession(true);

            session.setAttribute("initialized", "true");
            session.setAttribute("username", userObj.getUsername());
            session.setAttribute("userid", userObj.getUserid());
            session.setAttribute("companyid", userObj.getCompanyid());
            session.setAttribute("fullname", userObj.getFname()+" "+userObj.getLname());
            session.setAttribute("subdomain", userObj.getSubdomain());
    }

    public void destroyUserSession(HttpServletRequest request,
                    HttpServletResponse response) {
            request.getSession().invalidate();
    }
        
}
