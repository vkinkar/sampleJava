package com.sample.esp.handlers;

import com.sample.common.util.StringUtil;
import com.sample.database.DBUtil;
import com.sample.database.DbPool;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;



public class AuthHandler {
    
    public static JSONObject verifyLogin(Connection cn, String username,String passwd ,String subdomain) throws JSONException, Exception {
        
        JSONObject jObj = new JSONObject();
                
        ResultSet rs_main = null;
        PreparedStatement stmt = null;
        
         String SELECT_USER_INFO = " select u.userid,u.fname,u.lname,"
                 + "tb1.username,tb1.password,c.companyid,c.subdomain from users u "
                 + "left join userlogin as tb1 on u.userid = tb1.userid left join company as c on c.companyid=u.companyid "
                 + "where binary tb1.username =? and u.isActive=1 and binary tb1.password = ? and binary c.subdomain = ?";

        try {
            
            rs_main = DBUtil.executeQuery(cn,stmt, SELECT_USER_INFO, new Object[]{username,passwd,subdomain});

            if (rs_main.next()) {
                    jObj.put("username", rs_main.getString("username"));
                    jObj.put("firstName", rs_main.getString("fname"));
                    jObj.put("lastName", rs_main.getString("lname"));
                    jObj.put("userid", rs_main.getString("userid"));
                    jObj.put("companyid", rs_main.getString("companyid"));
                    jObj.put("subdomain", rs_main.getString("subdomain"));
                    jObj.put("success", true);
                    
            }else{
                    jObj.put("failure", true);
            }
            
        } catch (Exception e) {
                throw e;
        }finally{
            DbPool.closeStatement(stmt);
            DbPool.closeRS(rs_main);
         }
        
        return jObj;
    }
    public static String getUserName(HttpServletRequest request){
        String userName = NullCheckAndThrow(request.getSession().getAttribute("username"), "session.USERNAME_NULL");
        return userName;
    }
    public static String getCompanyid(HttpServletRequest request){
        String companyID = NullCheckAndThrow(request.getSession().getAttribute("companyid"), "session.COMPANYID_NULL");
        return companyID;
    }
    
    public static String getUserid(HttpServletRequest request){
            String userId = NullCheckAndThrow(request.getSession().getAttribute("userid"), "session.USERID_NULL");
        return userId;
    }

    public static String getUserFullName(HttpServletRequest request){
        String userName = NullCheckAndThrow(request.getSession().getAttribute("fullname"), "session.USERFULLNAME_NULL");
        return userName;
    }
    
    public static String getSubdomain(HttpServletRequest request){
        String subdomain = NullCheckAndThrow(request.getSession().getAttribute("subdomain"), "session.SUBDOMAIN_NULL");
        return subdomain;
    }
    
    private static String NullCheckAndThrow(Object objToCheck, String errorCode){
        if (objToCheck != null) {
            String oStr = objToCheck.toString();
            if (!StringUtil.isNullOrEmpty(oStr)) {
                return oStr;
            }
        }
        return errorCode;
        
    }

}