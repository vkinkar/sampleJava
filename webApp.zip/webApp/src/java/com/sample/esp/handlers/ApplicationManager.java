/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sample.esp.handlers;

import com.sample.common.util.ErrorMessages;
import com.sample.common.webapp.Employee;
import com.sample.database.DBUtil;
import com.sample.database.DbPool;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import org.json.JSONObject;

/**
 *
 * @author VISHAL
 */
public class ApplicationManager {
    public static String addEmployee(Connection conn, Employee empObj) throws SQLException, Exception{
        String res = "";
        ResultSet rs = null;
        PreparedStatement stmt = null;
        try{
            String uid = UUID.randomUUID().toString();
            java.sql.Date sqldt = new java.sql.Date(new java.util.Date().getTime());
            
            String createUser = "insert into employee(empid, empCompanyId, fname,lname,emailid,projectAllocationDate,"
                    + "contactno,isActive,companyid,createdby,createdon) VALUES (?,?,?,?,?,?,?,1,?,?,?)";
            DBUtil.executeUpdate(conn,stmt,createUser, new Object[]{uid,empObj.getEmpid(),empObj.getFname(),empObj.getLname(),
            empObj.getEmailid(),empObj.getProjectAllocationDate(),empObj.getContactNumber(),empObj.getCompanyid(),empObj.getCreatedby(),sqldt});
        
            res = "{\"success\":true}";
            
        }catch(SQLException e){
            //throw e;
            res = "{\"failure\":1}";
        }finally{
            DbPool.closeStatement(stmt);
            DbPool.closeRS(rs);
        }
        return res;
    }
    public static JSONObject viewEmployeeDetails(Connection conn, String companyid, String createdby,int page, int rows) throws Exception{
        
        JSONObject jObj = new JSONObject();
        ResultSet rs = null;
        ResultSet rs_count = null;
        PreparedStatement stmt = null;
         try{
            int start = (page-1)*rows;
	    int end = rows;
            
            String getCount = "select count(*) as count from employee where companyid=? and createdby=?";
            rs_count = DBUtil.executeQuery(conn,stmt, getCount, new Object[]{companyid,createdby}); 
            if(rs_count.next()){
                jObj.put("total", rs_count.getInt("count"));
            }
            
            
            String viewEmpDetails = "select * from employee where companyid=? and createdby=? limit ?,?";
            rs = DBUtil.executeQuery(conn,stmt,viewEmpDetails, new Object[]{companyid,createdby,start,end});
        
            //JSONArray empArr = new JSONArray();    
            while(rs.next()){
                JSONObject jloc = new JSONObject();

                jloc.put("employeeId", rs.getInt("empCompanyId"));
                jloc.put("employeeName", rs.getString("fname")+" "+rs.getString("lname"));
                jloc.put("employeeEmail", rs.getString("emailid"));
                jloc.put("projectJoiningDate", rs.getString("projectAllocationDate"));
                jloc.put("contactNumber", rs.getString("contactno"));
                jloc.put("isActive", rs.getBoolean("isActive")?"Yes":"No");

                jObj.append("rows", jloc);
            }
            jObj.put("success", true);
            
        }catch(SQLException e){
            //throw e;
            //return res = "{\"failure\":1}";
            jObj.put("success", false);
            jObj.put("failure", 1);
        }finally{
            DbPool.closeStatement(stmt);
            DbPool.closeRS(rs);
        }
        return jObj;
    }
}
